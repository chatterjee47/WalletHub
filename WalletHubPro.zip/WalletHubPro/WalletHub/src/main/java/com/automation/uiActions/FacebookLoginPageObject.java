package com.automation.uiActions;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class FacebookLoginPageObject {

	
	WebDriver driver;
	public static final Logger log = Logger.getLogger(FacebookLoginPageObject.class.getName());	

	
	@FindBy(xpath="//input[@id='email']")
	WebElement EmailTextBox;
	
	@FindBy(xpath="//input[@id='pass']")
	WebElement PasswordTextBox;
	
	@FindBy(xpath="//input[@aria-label='Log In']")
	WebElement Loginbutton;
	
	@FindBy(xpath="//div[@class='_1mf _1mj']")
	WebElement PostMessage;
	
	@FindBy(xpath="//button[@data-testid='react-composer-post-button']")
	WebElement ShareButton;
	
	
	
	
	public FacebookLoginPageObject(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setUserName(String strEmailTextBox){
		EmailTextBox.sendKeys(strEmailTextBox);
		log.info("Entering data into Email TextBox");	
	}
	
	public void setPassword(String strPassword){
		PasswordTextBox.sendKeys(strPassword);
		log.info("Entering data into Password TextBox");	
	}
	
	public void clickOnLoginButton() throws InterruptedException{
		Loginbutton.click();
		log.info("Clicking on Login button");
	}
	
	public void setPostMessage(String strPostMessage){
		PostMessage.sendKeys(strPostMessage);
		log.info("Entering data into Post TextBox");	
	}
	
	public void clickOnPostBox() throws InterruptedException{
		PostMessage.click();
		log.info("Clicking on PostBox button");
	}
	
	public void clickOnShareButton() throws InterruptedException{
		ShareButton.click();
		log.info("Clicking on Share button");
	}
	public void EnterDataIntoGeneralInformation(String UserName,String Password){
		try {
			this.setUserName(UserName);
			this.setPassword(Password);
			Thread.sleep(500);
			this.clickOnLoginButton();
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
}
