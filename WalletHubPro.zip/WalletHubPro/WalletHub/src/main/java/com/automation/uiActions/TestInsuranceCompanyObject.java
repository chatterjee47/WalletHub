package com.automation.uiActions;

import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class TestInsuranceCompanyObject {

	
	WebDriver driver;
	public static final Logger log = Logger.getLogger(TestInsuranceCompanyObject.class.getName());	

	
	@FindBy(xpath="//h3[@class='rsba-h3 bold-font']")
	By ScrollToRating;
	
	@FindBy(xpath="//div[@class='review-action ng-enter-element']//*[5]")
	WebElement FifthStar;
	
	@FindBy(xpath="//span[contains(text(),'Select...')]")
	WebElement HealthDropdown;
	
	@FindBy(xpath="//li[contains(text(),'Health Insurance')]")
	WebElement HealthInsuranceOption;
	
	@FindBy(xpath="//textarea[@placeholder='Write your review...']")
	WebElement ReviewTextbox;
	
	@FindBy(xpath="//div[@class='sbn-action semi-bold-font btn fixed-w-c tall']")
	WebElement SubmitButton;
	
	
	public void ScrollToRating() throws InterruptedException{
		WebElement element = driver.findElement(By.xpath("//h3[@class='rsba-h3 bold-font']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(500);
	}
	
	public void MouseOverToStar() throws InterruptedException{
	   Actions actions = new Actions(driver);
	   WebElement menuOption = driver.findElement(By.xpath("//div[@class='review-action ng-enter-element']//*[4]"));
	   actions.moveToElement(menuOption).perform();
	   System.out.println("Mouse Over action perform");
	}
	
	
	public TestInsuranceCompanyObject(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public void setReviewTextbox(String strReview){
		ReviewTextbox.sendKeys(strReview);
		log.info("Entering data into Review TextBox");	
	}
	
	public void clickOnFifthStar() throws InterruptedException{
		FifthStar.click();
		log.info("Clicking on Fifth Star");
	}
	
	public void clickOnHealthInsuranceOption() throws InterruptedException{
		HealthInsuranceOption.click();
		log.info("Clicking on Health Insurance Option");
	}
	
	public void clickOnHealthDropdown() throws InterruptedException{
		HealthDropdown.click();
		log.info("Clicking on Health Dropdown Option");
	}
	
	public void clickOnSubmitButton() throws InterruptedException{
		SubmitButton.click();
		log.info("Clicking on Submit Button");
	}
}
