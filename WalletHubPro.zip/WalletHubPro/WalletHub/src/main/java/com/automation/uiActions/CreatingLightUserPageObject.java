package com.automation.uiActions;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class CreatingLightUserPageObject {

	
	WebDriver driver;
	public static final Logger log = Logger.getLogger(CreatingLightUserPageObject.class.getName());	

	
	@FindBy(xpath="//input[@placeholder='Email Address']")
	WebElement LightEmailAddressTextBox;
	
	public void setLightEmailAddressTextBox(String strLightEmailAddressTextBox){
		LightEmailAddressTextBox.sendKeys(strLightEmailAddressTextBox);
		log.info("Entering data into Light Email Address TextBox");	
	}
	
	@FindBy(xpath="//input[@placeholder='Password']")
	WebElement LightPasswordTextBox;
	
	public void setLightPasswordTextBox(String strLightPasswordTextBox){
		LightPasswordTextBox.sendKeys(strLightPasswordTextBox);
		log.info("Entering data into Light Password TextBox");	
	}
	
	@FindBy(xpath="//input[@placeholder='Confirm Password']")
	WebElement LightConfirmPasswordTextBox;
	
	public void setLightConfirmPasswordTextBox(String strLightConfirmPasswordTextBox){
		LightConfirmPasswordTextBox.sendKeys(strLightConfirmPasswordTextBox);
		log.info("Entering data into Light Confirm Password TextBox");	
	}
	
	@FindBy(xpath="//span[contains(text(),'Get my free credit score & report')]")
	WebElement FreeCreditScoreCheckBox;
	
	public void clickOnFreeCreditScoreCheckBox() throws InterruptedException{
		FreeCreditScoreCheckBox.click();
		log.info("Clicking on Free Credit Score CheckBox");
	}
	
	@FindBy(xpath="//button[@class='btn blue touch-element-cl']")
	WebElement JoinButton;
	
	public void clickOnJoinButton() throws InterruptedException{
		JoinButton.click();
		log.info("Clicking on Join Button");
	}
	
	public CreatingLightUserPageObject(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
