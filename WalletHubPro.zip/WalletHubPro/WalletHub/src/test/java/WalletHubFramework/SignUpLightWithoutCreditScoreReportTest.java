package WalletHubFramework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.automation.Base.Base;
import com.automation.uiActions.CreatingLightUserPageObject;


public class SignUpLightWithoutCreditScoreReportTest extends Base{

	public static final Logger log = Logger.getLogger(CreatingLightUserPageObject.class.getName());	
	CreatingLightUserPageObject SignUp;
	
	@BeforeMethod
	public void beforeMethod(Method method) throws InterruptedException{
	try {
		init();
		
		String path = System.getProperty("user.dir");
		String otherFolder = path + "\\configs\\Configuration.properties";
		 File file = new File(otherFolder);
		  
			FileInputStream fileInput = null;
			try {
				fileInput = new FileInputStream(file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			Properties prop = new Properties();
			
			//load properties file
			try {
				prop.load(fileInput);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		driver.get(prop.getProperty("LightUserUrl"));
	} catch (IOException e) {
		e.printStackTrace();
	}
	SignUp = new CreatingLightUserPageObject(driver);
	
	}
	
	@DataProvider(name="loginData")
	public String[][] getTestData(){
		String[][] testRecords = getData("TestData.xlsx", "SignUpLightWithoutCreditScoreR");
		return testRecords;
	}
	
	@Test(dataProvider="loginData")
	public void SignUpLightWithoutCreditScoreReport(String EmailAddress, String LightPassword, String LightConfirmPassword, String runMode) {
		SignUp = new CreatingLightUserPageObject(driver);
		if(runMode.equalsIgnoreCase("N")){
			throw new SkipException("user marked this record as no run");
		}
		try {
			log.info("============= Starting SignUp Functionality Test =============");
			Thread.sleep(1000);
			SignUp.setLightEmailAddressTextBox(EmailAddress);
			SignUp.setLightPasswordTextBox(LightPassword);
			SignUp.setLightConfirmPasswordTextBox(LightConfirmPassword);
			SignUp.clickOnFreeCreditScoreCheckBox();
			SignUp.clickOnJoinButton();
			Thread.sleep(10000);
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
			wait.pollingEvery(250, TimeUnit.MILLISECONDS);
			wait.withTimeout(2, TimeUnit.SECONDS);
			log.info("============= Finished SignUp Functionality Test =============");
		} catch (Exception e) {
			getScreenShot("SignUpLightWithoutCreditScoreReport");
		}
	}


	@AfterMethod
	public void endTest() {
        driver.close();
       
      	}
}